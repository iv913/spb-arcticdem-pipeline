# Pipeline: Коррекция ArcticDEM по опорным объектам → карта затопления СПб

## Архитектура (5 модулей + 3 вспомогательных)

### 01_owner_map.py — Семантическое разбиение DEM по OSM
- Owner map: 0=other, 1=road, 2=sidewalk, 3=green, 4=building(+3м), 5=water
- Сшитые мультиполигоны (stitch_rings + polygonize) для рек/каналов
- merge_water: полигоны приоритет, линии буферизуются только если <60% покрытия
- Дисплей-варп EPSG:3413 → EPSG:3857 (Web Mercator) для folium
- CSS image-rendering:pixelated (отключает браузерную интерполяцию)
- Вход: ArcticDEM (EPSG:3413, 2m), OSM Overpass
- Выход: owner_map.tif (2 band: owner + quality), owner_qa_map.html, carriageway.geojson

### city_calibration.py + city_local_ground_v3.py — Городская калибровка
- corridor_ground: коридор вдоль OSM-way (40→250м адаптивно), блочные медианы 6×6м
- Отсев нижнего кластера (вода/ямы), повторная медиана [floor, floor+0.6м]
- Якорный критерий: коридор пересекает другие проезжие улицы
- 202 точки → 85 ok → 27 inlier-улиц → shift=15.92м (bias DEM ≈ 0)
- Выход: city_calibration.json (shift_m=15.92, SHIFT_SIGMA=0.80)

### 02_road_reconstruct.py — Робастная реконструкция поверхности
- h(pk, off) = f(picket) + g(offset), 2-pass: long→cross→long
- Прореживание бинов: shadow_jump + slope + zone_fill (консолидация зон)
- MAD(clean)=0.21м, потолок inlier tol=0.50м
- Подхватывает fused_profile.csv (модуль 02b) — restored/confirmed бины
- Вертикальная привязка: CITY_SHIFT=15.92м (city_calibration_v3)
- Выход: road_surface.tif (band1: h_bs77, band2: source 1/2/3)

### download_arcticdem_strips.py — Скачивание стрипов
- PGC STAC API: https://stac.pgc.umn.edu/api/v1/
- Collection: arcticdem-strips-s2s041-2m
- 10 стрипов (2014×3, 2020×1, 2022×5) + mosaic clip
- /vsicurl/ для потокового клипа (без полного скачивания)
- Выход: strips/manifest.json + strip_*_vo_clip.tif

### multi_dem_profile.py — Профиль по всем DEM
- corridor_ground на 200 точках вдоль оси + _prune_bins
- Выход: profiles/profile_<source>.csv (b, pk, h, kept)

### 02b_profile_fusion.py — Мультемпоральный fusion
- Theil-Sen выравнивание: dh(pk) = a + b·pk (сдвиг + наклон)
- По-бинные ворота: edge trim 100м, gate vs ref 0.6м, verified restoration 0.75м
- 3 accepted (mosaic + 2020 + 2022-03-10), 6 dropped
- Выход: fused_profile.csv (b, pk, h_fused, n_src, status, h_<source>...)

### 02c_full_profile_analysis.py — Анализ всего проспекта
- Только accepted + aligned (Theil-Sen) источники
- std между DEM ПОСЛЕ ворот = детектор машин (median=0.107м, max=0.271м)
- Рельеф: dh=−0.92м на 2840м, уклон=−0.052%, размах=2.42м
- Выход: full_profile_analysis.png/json, per_picket.csv

### 03_flood_map.py — Карта затопления
- Статическая ванна + гидросвязность (вода OSM + торцы улицы)
- Три маски: pessimistic (depth>u), best (depth>0), optimistic (depth>−u)
- Бюджет: форма 0.107 ⊕ привязка 0.80 ⊕ класс (0.15/0.30/0.80)
- Уровни 0.5–3.0м БС-77, шаг 0.5м; >1.6м — сценарий отказа КЗС
- Выход: flood_map_bolshoy.html, flood_qa.json

## Ключевые числа
- shift = 15.92м (GEOID 15.9 + bias DEM ≈ 0)
- profile_h_bs77 = [1.89, 4.40]м (паспорт 3.61м ✓)
- std между DEM (после ворот) = 0.107м (медиана)
- SHIFT_SIGMA = 0.80м (межуличный MAD, 27 inlier-улиц)
- V.O.-local MAD = 0.013м (4 улицы, слишком мало) / Mainland MAD = 0.382м
- Бюджет ошибки: measured ±0.82, reconstructed ±0.86, extrapolated ±1.14м
- При H=2.5м: 0% (pess) .. 17% (best) .. 41% (opt) длины затоплено

## Запуск (по порядку)
```bash
python3 scripts/01_owner_map.py          # owner map
python3 scripts/city_calibration.py       # городской shift (требует v3 helper)
python3 scripts/download_arcticdem_strips.py  # стрипы (требует pystac-client)
python3 scripts/multi_dem_profile.py      # профили по всем DEM
python3 scripts/02b_profile_fusion.py     # fusion (Theil-Sen + ворота)
python3 scripts/02_road_reconstruct.py    # реконструкция поверхности
python3 scripts/02c_full_profile_analysis.py  # анализ всего проспекта
python3 scripts/03_flood_map.py           # карта затопления
```
